﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace demka.Pages
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        SqlConnection con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=iscand;Integrated Security=True");
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Login_Click(object sender, RoutedEventArgs e)
        {
            SqlDataAdapter da = new SqlDataAdapter(
                "SELECT * FROM Users WHERE Login='" + login.Text + "' AND Password='" + pass.Password + "'", con);

            DataTable dt = new DataTable();
            da.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                new ProductWindow().Show();
                this.Close();
            }
            else
            {
                MessageBox.Show("Ошибка входа");
                MessageBox.Show(dt.Rows.Count.ToString());
            }

        }


        private void Guest_Click(object sender, RoutedEventArgs e)
        {
            new ProductWindow().Show();
            this.Close();
        }
    }
}

