﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace demka
{
    public static class DB
    {
        public static SqlConnection connection = new SqlConnection(
            @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=iscand;Integrated Security=True");
    }
}